from flask import Flask, request
server_port = 5000
app = Flask(__name__)
@app.route('/',methods = ['GET'])
def hello_world():
    return 'Hello, World!'
@app.route('/post', methods=['POST'])
def handle_post():
    if request.method == 'POST':
        print(request.data)
        return '<h1>valid credentials!</h1>'
if __name__ == "__main__":
    app.run('localhost',port=server_port)