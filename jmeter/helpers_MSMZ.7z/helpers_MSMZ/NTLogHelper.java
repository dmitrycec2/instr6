package helpers;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

public class NTLogHelper {
   private Logger logger;
   private static final String SEPARATOR = "--------------------------";
   private static final String CLASS_SEPARATION = ":\n";
   private static final String NO_EXCEPTION = "NO EXCEPTION MESSAGE";
   public static final String CANT_FIND_STORE_ERROR = "shop not found";
   public static final String CANT_CREATE_STORE_ERROR = "store not created";
   public static final String CANT_SEARCH_ERROR = "can't do searchStore";
   public static final String CANT_CREATE_ERROR = "can't create store";
   public static final String LOGIN_ERROR = "login";
   public static final String LOGOUT_ERROR = "logout";
   public static final String WRITE_MAIN_LOGS_ERROR = "can't write main logs";

   public NTLogHelper(Class currentClass) {
      this.logger = LogManager.getLogger(currentClass);
      this.logger.addAppender(new ConsoleAppender(new PatternLayout("%-5p- %m%n")));
   }

   public void logInfo(String message) {
      this.logger.info(this.getInfoMessage(message));
   }

   public void logError(String description) {
      this.logError(description, (Exception)null);
   }

   public void logError(String description, Exception error) {
      this.logger.error(this.getStandardErrorMessage(description, this.getMessageFromException(error)));
   }

   public void logTransactionError(String transaction, String description) {
      this.logTransactionError(transaction, description, (Exception)null);
   }

   public void logTransactionError(String transaction, String description, Exception error) {
      this.logger.error(this.getFullErrorMessage(transaction, description, this.getMessageFromException(error)));
   }

   private String getStandardErrorMessage(String description, String errorMsg) {
      return "\n--------------------------\nERROR:\n" + description + "\n" + errorMsg + "\n" + "--------------------------";
   }

   private String getFullErrorMessage(String transaction, String description, String errorMsg) {
      return "\n--------------------------\nTRANSACTION ERROR:\n" + description + "\n" + transaction + "\n" + errorMsg + "\n" + "--------------------------";
   }

   private String getInfoMessage(String message) {
      return message;
   }

   private String getMessageFromException(Exception error) {
      if (error == null) {
         return "NO EXCEPTION MESSAGE";
      } else {
         StringBuffer resultMessage = new StringBuffer(error.getMessage());
         StackTraceElement[] var3 = error.getStackTrace();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            StackTraceElement stackTraceElement = var3[var5];
            resultMessage.append("\n").append(stackTraceElement.getClassName());
         }

         return resultMessage.toString();
      }
   }
}
