package helpers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class NTFileHelper {
   public static boolean createFile(String filePath, String fileName) {
      try {
         File folder = new File("./test");
         if (folder.mkdirs()) {
            File file = new File("./test/1.txt");
            new FileOutputStream(file);
         }
      } catch (FileNotFoundException var5) {
         var5.printStackTrace();
      }

      return true;
   }

   public static String delNoDigOrLet(String s) {
      StringBuilder sb = new StringBuilder();

      for(int i = 0; i < s.length(); ++i) {
         if (Character.isLetterOrDigit(s.charAt(i))) {
            sb.append(s.charAt(i));
         }
      }

      return sb.toString();
   }
   public static List<File> listFilesFilter(List<File> lf, String myregexp) {
	      List<File> resultInfo = new ArrayList();
	      Iterator it1 = lf.iterator();
	      while(it1.hasNext()) {
		         File file = (File)it1.next();
		         String checkName = file.getName();
		         if (checkName.matches(myregexp)) resultInfo.add(file);
	      }
	return resultInfo;
	   
   }
   public static List<File> listFilesFromFolder(String path) {
      List<File> files = new ArrayList();
      File[] filesArray = (new File(path)).listFiles();
      if (filesArray != null && filesArray.length >= 1) {
         File[] var3 = filesArray;
         int var4 = filesArray.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            File fileEntry = var3[var5];
            if (!fileEntry.isDirectory()) {
               files.add(fileEntry);
            }
         }

         return files;
      } else {
         return files;
      }
   }
   
   public static List<File> listSubFolders(String path) {
	   Path directory = Paths.get(path);
		List<File> directories = null;
		try {
		     directories =
		            Files.walk(directory)
		                 .filter(Files::isDirectory)
		                 .map(Path::toFile)
		                 .collect(Collectors.toList());
		} catch (IOException e) {
		    // process exception
		}
	return directories;
	   }

   
   public static List<File> listFilesFromSubFolder(String path) {
	      List<File> files = new ArrayList();
	      List<File> directories = listSubFolders(path);
	      
	      for (File myFile : directories) {
		      File[] filesArray = myFile.listFiles();
		      if (filesArray != null && filesArray.length >= 1) {
		         File[] var3 = filesArray;
		         int var4 = filesArray.length;

		         for(int var5 = 0; var5 < var4; ++var5) {
		            File fileEntry = var3[var5];
		            if (!fileEntry.isDirectory()) {
		               files.add(fileEntry);
		            }
		         }
		      } 
	    	}
		return files;

	   }
   
   
   
   public static List<String> getFileInfo(String pathToFile) throws Exception {
      ArrayList results = new ArrayList();

      try {
         FileInputStream myFile = new FileInputStream(pathToFile);
         Throwable var3 = null;

         try {
            InputStreamReader inputStreamReader = new InputStreamReader(myFile, StandardCharsets.UTF_8);
            Throwable var5 = null;

            try {
               BufferedReader reader = new BufferedReader(inputStreamReader);
               Throwable var7 = null;

               try {
                  String line;
                  try {
                     while((line = reader.readLine()) != null) {
                        results.add(line);
                     }
                  } catch (Throwable var54) {
                     var7 = var54;
                     throw var54;
                  }
               } finally {
                  if (reader != null) {
                     if (var7 != null) {
                        try {
                           reader.close();
                        } catch (Throwable var53) {
                           var7.addSuppressed(var53);
                        }
                     } else {
                        reader.close();
                     }
                  }

               }
            } catch (Throwable var56) {
               var5 = var56;
               throw var56;
            } finally {
               if (inputStreamReader != null) {
                  if (var5 != null) {
                     try {
                        inputStreamReader.close();
                     } catch (Throwable var52) {
                        var5.addSuppressed(var52);
                     }
                  } else {
                     inputStreamReader.close();
                  }
               }

            }
         } catch (Throwable var58) {
            var3 = var58;
            throw var58;
         } finally {
            if (myFile != null) {
               if (var3 != null) {
                  try {
                     myFile.close();
                  } catch (Throwable var51) {
                     var3.addSuppressed(var51);
                  }
               } else {
                  myFile.close();
               }
            }

         }

         return results;
      } catch (IOException var60) {
         throw var60;
      }
   }

   public static List<String> getFileInfoRegExp(String pathToFile, String checkRegExp) throws Exception {
      ArrayList results = new ArrayList();

      try {
         FileInputStream myFile = new FileInputStream(pathToFile);
         Throwable var4 = null;

         try {
            InputStreamReader inputStreamReader = new InputStreamReader(myFile, StandardCharsets.UTF_8);
            Throwable var6 = null;

            try {
               BufferedReader reader = new BufferedReader(inputStreamReader);
               Throwable var8 = null;

               try {
                  String line;
                  try {
                     while((line = reader.readLine()) != null) {
                        if (line.matches(checkRegExp)) {
                           results.add(line);
                        }
                     }
                  } catch (Throwable var55) {
                     var8 = var55;
                     throw var55;
                  }
               } finally {
                  if (reader != null) {
                     if (var8 != null) {
                        try {
                           reader.close();
                        } catch (Throwable var54) {
                           var8.addSuppressed(var54);
                        }
                     } else {
                        reader.close();
                     }
                  }

               }
            } catch (Throwable var57) {
               var6 = var57;
               throw var57;
            } finally {
               if (inputStreamReader != null) {
                  if (var6 != null) {
                     try {
                        inputStreamReader.close();
                     } catch (Throwable var53) {
                        var6.addSuppressed(var53);
                     }
                  } else {
                     inputStreamReader.close();
                  }
               }

            }
         } catch (Throwable var59) {
            var4 = var59;
            throw var59;
         } finally {
            if (myFile != null) {
               if (var4 != null) {
                  try {
                     myFile.close();
                  } catch (Throwable var52) {
                     var4.addSuppressed(var52);
                  }
               } else {
                  myFile.close();
               }
            }

         }

         return results;
      } catch (IOException var61) {
         throw var61;
      }
   }

   public static String getFileAsString(String pathToFile) throws Exception {
      StringBuffer buffer = new StringBuffer();

      try {
         FileInputStream myFile = new FileInputStream(pathToFile);
         Throwable var3 = null;

         try {
            InputStreamReader inputStreamReader = new InputStreamReader(myFile, StandardCharsets.UTF_8);
            Throwable var5 = null;

            try {
               Reader reader = new BufferedReader(inputStreamReader);
               Throwable var7 = null;

               try {
                  int symbol;
                  try {
                     while((symbol = reader.read()) > -1) {
                        buffer.append((char)symbol);
                     }
                  } catch (Throwable var54) {
                     var7 = var54;
                     throw var54;
                  }
               } finally {
                  if (reader != null) {
                     if (var7 != null) {
                        try {
                           reader.close();
                        } catch (Throwable var53) {
                           var7.addSuppressed(var53);
                        }
                     } else {
                        reader.close();
                     }
                  }

               }
            } catch (Throwable var56) {
               var5 = var56;
               throw var56;
            } finally {
               if (inputStreamReader != null) {
                  if (var5 != null) {
                     try {
                        inputStreamReader.close();
                     } catch (Throwable var52) {
                        var5.addSuppressed(var52);
                     }
                  } else {
                     inputStreamReader.close();
                  }
               }

            }
         } catch (Throwable var58) {
            var3 = var58;
            throw var58;
         } finally {
            if (myFile != null) {
               if (var3 != null) {
                  try {
                     myFile.close();
                  } catch (Throwable var51) {
                     var3.addSuppressed(var51);
                  }
               } else {
                  myFile.close();
               }
            }

         }
      } catch (IOException var60) {
         throw var60;
      }

      return buffer.toString();
   }

   public static void writeListToFile(List<String> output, String filePath, boolean append) throws Exception {
      try {
         FileOutputStream myFile = new FileOutputStream(String.valueOf(Paths.get(filePath)), append);
         Throwable var4 = null;

         try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(myFile, StandardCharsets.UTF_8);
            Throwable var6 = null;

            try {
               Writer out = new BufferedWriter(outputStreamWriter);
               Throwable var8 = null;

               try {
                  if (append) {
                     out.append("\r\n");
                  }

                  Iterator var9 = output.iterator();

                  while(var9.hasNext()) {
                     String string = (String)var9.next();
                     out.append(string);
                     if (var9.hasNext()) out.append("\r\n");
                  }
               } catch (Throwable var56) {
                  var8 = var56;
                  throw var56;
               } finally {
                  if (out != null) {
                     if (var8 != null) {
                        try {
                           out.close();
                        } catch (Throwable var55) {
                           var8.addSuppressed(var55);
                        }
                     } else {
                        out.close();
                     }
                  }

               }
            } catch (Throwable var58) {
               var6 = var58;
               throw var58;
            } finally {
               if (outputStreamWriter != null) {
                  if (var6 != null) {
                     try {
                        outputStreamWriter.close();
                     } catch (Throwable var54) {
                        var6.addSuppressed(var54);
                     }
                  } else {
                     outputStreamWriter.close();
                  }
               }

            }
         } catch (Throwable var60) {
            var4 = var60;
            throw var60;
         } finally {
            if (myFile != null) {
               if (var4 != null) {
                  try {
                     myFile.close();
                  } catch (Throwable var53) {
                     var4.addSuppressed(var53);
                  }
               } else {
                  myFile.close();
               }
            }

         }

      } catch (NullPointerException | IOException var62) {
         throw var62;
      }
   }

   public static void writeStringToFile(String outString, String filePath, boolean append) throws Exception {
      try {
         FileOutputStream myFile = new FileOutputStream(String.valueOf(Paths.get(filePath)), append);
         Throwable var4 = null;

         try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(myFile, StandardCharsets.UTF_8);
            Throwable var6 = null;

            try {
               Writer out = new BufferedWriter(outputStreamWriter);
               Throwable var8 = null;

               try {
                  if (append) {
                     out.write("\r\n");
                  }

                  out.write(outString);
               } catch (Throwable var55) {
                  var8 = var55;
                  throw var55;
               } finally {
                  if (out != null) {
                     if (var8 != null) {
                        try {
                           out.close();
                        } catch (Throwable var54) {
                           var8.addSuppressed(var54);
                        }
                     } else {
                        out.close();
                     }
                  }

               }
            } catch (Throwable var57) {
               var6 = var57;
               throw var57;
            } finally {
               if (outputStreamWriter != null) {
                  if (var6 != null) {
                     try {
                        outputStreamWriter.close();
                     } catch (Throwable var53) {
                        var6.addSuppressed(var53);
                     }
                  } else {
                     outputStreamWriter.close();
                  }
               }

            }
         } catch (Throwable var59) {
            var4 = var59;
            throw var59;
         } finally {
            if (myFile != null) {
               if (var4 != null) {
                  try {
                     myFile.close();
                  } catch (Throwable var52) {
                     var4.addSuppressed(var52);
                  }
               } else {
                  myFile.close();
               }
            }

         }

      } catch (NullPointerException | IOException var61) {
         throw var61;
      }
   }
}
