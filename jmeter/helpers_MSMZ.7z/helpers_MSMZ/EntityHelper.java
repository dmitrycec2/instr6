package helpers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import entity.Atd;

import entity.Xml;

public class EntityHelper {
   private NTLogHelper logger;
   private ConcurrentHashMap<String, Atd> atdMap;
   private LinkedHashSet dateList;
   String currentPath, outPath;
   
   public EntityHelper(NTLogHelper logger, ConcurrentHashMap<String, Atd> atdMap, LinkedHashSet datelist2, String currentPath, String outPath) {
	   this.logger = logger;
	   this.atdMap = atdMap;
	   this.dateList = datelist2;
	   this.currentPath = currentPath;
	   this.outPath = outPath;
   }


   public boolean DoCreate(List<File> filesInWork, List<File> filesInWork2){
	   	String starttime = null;
	    Iterator it1 = filesInWork.iterator();
	      while(it1.hasNext()) {
	    	  File file = (File)it1.next();
		         String checkName = file.getName();
		         if (checkName.matches("starttime.csv")) {
		        	 
		        	 try(BufferedReader br = new BufferedReader(new FileReader(file.getAbsolutePath()))) {
		        		 starttime = br.readLine(); 
		        	    } catch (IOException e) {}
		         }
	      }
	      it1=filesInWork2.iterator();
	      while(it1.hasNext()) {
	         File file = (File)it1.next();	                         
	         String checkName = file.getName();
	         //get path and newPAth for save in current ATD entity
	         String path = file.getPath(); 
	         String newpath = getPath(path, currentPath,checkName);
	  	     String[] lineElem = checkName.split("_", -1);
	         String azkName = lineElem[1].trim();
	         String azkDate = lineElem[2].trim();	       
	         String[] lineElem2 = azkDate.split("-", -1);
	         				dateList.add(lineElem2[0].trim());	         				
	        	        	createXml(starttime,azkName, path, newpath);
	      }
	return true;
   }

   public boolean createXml(String startTime1, String azk_id, String path, String newpath) {   	   
	   Atd atd=atdMap.get(azk_id);
    		  if(atd==null) {
    			   atd= new Atd(startTime1, azk_id, path, newpath);
    			   atdMap.put(azk_id, atd);   	
    		       } else {
    		    	   atd.putFilePath(path, newpath);} 

      return true;
   }
   

   
   public Atd getXml(String name) {
	   Atd atd = atdMap.get(name);
       if (atd == null) {
    	   return null;
       }
      return atd;
   }

   public String getPath(String path, String currentPath, String name) {
	   String currentPath2 = currentPath.replaceAll("\\\\", "\\\\\\\\");
	   String name2 = name.replaceAll("\\\\", "\\\\\\\\");
	   String newpath = null;
	   Pattern pattern = Pattern.compile(currentPath2+"(.*?)"+name2, Pattern.DOTALL);
	   Matcher matcher = pattern.matcher(path);
	   while (matcher.find()) {
	       System.out.println(matcher.group(1));
	       newpath = matcher.group(1);
	      /* try {
			Files.createDirectories(Paths.get(outPath+newpath));
		} catch (IOException e) {
			e.printStackTrace();
		}*/
	   }
	   
  
	   
      return newpath;
   }

}
