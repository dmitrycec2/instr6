package helpers;


public class NTNumbersHelper {
	   public static int rnd(int min, int max)
	   {
	       max -= min;
	       return (int) (Math.random() * ++max) + min;
	   }
	   

}
