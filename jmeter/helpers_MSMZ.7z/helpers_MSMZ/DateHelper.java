package helpers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateHelper {
	public static long globalTime;
	protected static long maxglobalTime;
	private long maxglobalTimeFile;
	String startTime1 = null;	
	String oldFormat = "yyyy-MM-dd HH:mm:ss";		
	SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);	
	SimpleDateFormat fileNameFormat =new SimpleDateFormat("yyyyMMdd-HHmmss"); 
	SimpleDateFormat myformat = new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat myformat3 = new SimpleDateFormat("HH:mm:ss");
	Date dt;
	
	public DateHelper(String startTime1) {
		super();
		this.startTime1 = startTime1;
		try {
			dt=sdf.parse(startTime1);
		} catch (ParseException e) {
			e.printStackTrace();
		} 
		globalTime = dt.getTime();
		maxglobalTime=globalTime;
		maxglobalTimeFile=globalTime;

	}

	public String getMaxGlobalTime() {
		//return maxglobalTime;
		Date fDate = new Date(maxglobalTime);
		return myformat.format(fDate)+" "+myformat3.format(fDate);
	}
	public static void setMaxGlobalTime(long maxglobalTime) {
		if(maxglobalTime>DateHelper.maxglobalTime)
		DateHelper.maxglobalTime = maxglobalTime;
	}
	public void setMaxGlobalTimeFile(long maxglobalTimeFile) {
		if(maxglobalTime>this.maxglobalTimeFile)
		this.maxglobalTimeFile = maxglobalTimeFile;
	}


	public String getfileNameTime(){	
		maxglobalTimeFile=maxglobalTimeFile+2000;
		Date fDate = new Date(maxglobalTimeFile);
		return fileNameFormat.format(fDate);
	   }
	public static void globaltimeToMaxTime(){	
		globalTime = maxglobalTime;
	   }
	public void maxglobalTimeFileToMaxTime(){	
		this.maxglobalTimeFile = maxglobalTime;
	   }


}
